# adaptive_picard_chebyshev
This folder contains the adaptive Picard-Chebyshev C code for propagating orbits around the Earth, using cartesian coordinates.
